<?php
/*
Plugin Name: Custom SMTP Setup
Description: Configure SMTP settings for google gmail from the admin panel.
Version: 1.0
Author: Hardy Infotech
*/

// Hook to add plugin settings page
add_action('admin_menu', 'custom_smtp_setup_menu');
add_action('admin_init', 'custom_smtp_setup_settings');

// Add Settings Menu
function custom_smtp_setup_menu() {
    add_menu_page(
        'Custom SMTP Settings',   // Page Title
        'SMTP Settings',          // Menu Title
        'administrator',          // Required capability
        'custom-smtp-settings',   // Menu Slug
        'custom_smtp_settings_page', // Callback function
        'dashicons-email-alt',    // Icon
        90                        // Position
    );
}

// Display settings page
function custom_smtp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom SMTP Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('custom_smtp_group');
            do_settings_sections('custom-smtp-settings');
            submit_button('Save Settings');
            ?>
        </form>
    </div>
    <?php
}

// Register settings
function custom_smtp_setup_settings() {
    // Register the options group
    register_setting(
        'custom_smtp_group',      // Option group
        'custom_smtp_options'    // Option name
    );

    // Add section
    add_settings_section(
        'custom_smtp_section',   // Section ID
        'SMTP Configuration',    // Section Title
        'custom_smtp_section_callback', // Callback
        'custom-smtp-settings'   // Page to display section
    );

    // Add fields
    add_settings_field(
        'mailer',                // Field ID
        'Mailer',                // Field title
        'custom_mailer_callback',// Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_host',             // Field ID
        'SMTP Host',             // Field title
        'custom_smtp_host_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_port',             // Field ID
        'SMTP Port',             // Field title
        'custom_smtp_port_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_username',         // Field ID
        'SMTP Username',         // Field title
        'custom_smtp_username_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_password',         // Field ID
        'SMTP Password',         // Field title
        'custom_smtp_password_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_from',             // Field ID
        'SMTP From Email',       // Field title
        'custom_smtp_from_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );

    add_settings_field(
        'smtp_from_name',        // Field ID
        'SMTP From Name',        // Field title
        'custom_smtp_from_name_callback', // Callback function
        'custom-smtp-settings',  // Page to display field
        'custom_smtp_section'    // Section ID
    );
}

// Section callback (optional)
function custom_smtp_section_callback() {
    echo 'Configure your Google (gmail) SMTP settings below:';
}

// Input field callbacks
function custom_mailer_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="text" name="custom_smtp_options[mailer]" value="' . esc_attr($options['mailer'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_host_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="text" name="custom_smtp_options[smtp_host]" value="' . esc_attr($options['smtp_host'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_port_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="text" name="custom_smtp_options[smtp_port]" value="' . esc_attr($options['smtp_port'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_username_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="text" name="custom_smtp_options[smtp_username]" value="' . esc_attr($options['smtp_username'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_password_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="password" name="custom_smtp_options[smtp_password]" value="' . esc_attr($options['smtp_password'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_from_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="email" name="custom_smtp_options[smtp_from]" value="' . esc_attr($options['smtp_from'] ?? '') . '" class="regular-text" />';
}

function custom_smtp_from_name_callback() {
    $options = get_option('custom_smtp_options');
    echo '<input type="text" name="custom_smtp_options[smtp_from_name]" value="' . esc_attr($options['smtp_from_name'] ?? '') . '" class="regular-text" />';
}

// Hook into the wp_mail() function to send email using custom SMTP settings
add_action('phpmailer_init', 'custom_smtp_mailer');

function custom_smtp_mailer($phpmailer) {
    // Get the saved SMTP options from the database
    $options = get_option('custom_smtp_options');

    // Ensure the options are set and are an array, otherwise provide a default empty array
    if (is_array($options) && !empty($options['smtp_host'])) {
        // Use SMTP settings if they exist
        $phpmailer->isSMTP();    
        $phpmailer->Mailer = isset($options['mailer']) ? $options['mailer'] : '';      // SMTP server
        $phpmailer->Host = isset($options['smtp_host']) ? $options['smtp_host'] : '';      // SMTP server
        $phpmailer->SMTPAuth = true;                   // Enable SMTP authentication
        $phpmailer->Username = isset($options['smtp_username']) ? $options['smtp_username'] : ''; // SMTP username
        $phpmailer->Password = isset($options['smtp_password']) ? $options['smtp_password'] : ''; // SMTP password
        $phpmailer->SMTPSecure ='587'; // Encryption (TLS)
        $phpmailer->Port = isset($options['smtp_port']) ? $options['smtp_port'] : 587;      // SMTP port
        $phpmailer->From = isset($options['smtp_from']) ? $options['smtp_from'] : '';      // From email address
        $phpmailer->FromName = isset($options['smtp_from_name']) ? $options['smtp_from_name'] : ''; // From name
    }
}
?>
